<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/home.css"/>
<title>::. FUD School Manager.::</title>
</head>

<body>
<div id="content">
	<div >
    	<img src="picture/master1.png" width="805" height="308"  />
    </div>
    
    <div id="space"></div>
    
    <div id="question">
    	What do you know about Federal University Dutse?
    </div>
    
    <div id="space"></div>
    
    <div style="text-indent:40px; text-align:justify">The Federal University Dutse, is one of the nine universities created by the Federal Government of Nigeria in 2011. FUD offers both undergraduate and postgraduate programs The Federal University, Dutse held its first convocation ceremony on January 16, 2016
The university's campus is located in the ancient town of Dutse the capital of Jigawa State. FUD seeks to attract a diverse cast of lecturers and students, support research and teaching on local, national and global issues and create academic relationships with many universities and higher education institutions in Nigeria and across the world. FUD is offering a broad range of degree programs in Humanities, Natural and the Social Sciences, Agricultural Science and also in Medicine. Faculties in offerings are Faculty of law, faculty of engineering and faculty of management science to take up this year. From the university's pioneer crop of 205 students enrolled in four academic programmes in three faculties had grown to about 3,200 students in the university's fifth academic year of operation, while there are 1,332 academic and non-teaching staff. The number courses in the university now stand at 17..</div>
</div><!--end of content -->
</body>
</html>